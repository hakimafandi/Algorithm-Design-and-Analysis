// *********************************************************
// Program: group127_num01_kruskalwithoutpq_am_0000006_output.cpp
// Course: TCP2101 ALGORITHM DESIGN & ANALYSIS
// Class: TC1L
// Trimester: 2220
// Member_1: 1211300373 | Anis Hazirah binti Mohamad Sabry | 1211300373@student.mmu.edu.my | 018-2740855
// Member_2: 1201101577 | Danial bin Muhammad Firdaus Anson | 1201101577@student.mmu.edu.my | 017-2652631
// Member_3: 1161200826 | Luqman Hakim Zahir Bin Afandi | 1161200826@student.mmu.edu.my | 019-6939665
// Member_4: 1211303209 | Nuha Awadah binti Mohd Yusof | 1211303209@student.mmu.edu.my |  014-3380062
// *********************************************************
// Task Distribution
// Member_1:  Huffman
// Member_2:  Input files
// Member_3:  Kruskal without priority queue
// Member_4: Kruskal with priority queue
// *********************************************************

#include <iostream>
#include <fstream>
#include <vector>
#include <algorithm>
#include <chrono>

using namespace std;

// Structure to represent an edge in the graph
struct Edge {
    int src, dest, weight;
};

// Structure to represent a graph
struct Graph {
    int V, E;
    vector<Edge> edges;
};

// Structure to represent a subset (used in Union-Find algorithm)
struct Subset {
    int parent, rank;
};

// Function to find the parent of a subset
int find(Subset subsets[], int i) {
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);
    return subsets[i].parent;
}

// Function to perform union operation of two subsets
void Union(Subset subsets[], int x, int y) {
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);

    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
    else {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}

// Function to find the minimum spanning tree using Kruskal's algorithm
vector<Edge> KruskalMST(Graph graph) {
    int V = graph.V;
    vector<Edge> result;

    // Sort the edges in non-decreasing order of their weights
    sort(graph.edges.begin(), graph.edges.end(),
         [](const Edge& a, const Edge& b) {
             return a.weight < b.weight;
         });

    // Create subsets for Union-Find algorithm
    Subset* subsets = new Subset[V];
    for (int v = 0; v < V; v++) {
        subsets[v].parent = v;
        subsets[v].rank = 0;
    }

    int e = 0, i = 0;
    while (e < V - 1 && i < graph.E) {
        // Get the next smallest edge from the sorted edges
        Edge next_edge = graph.edges[i++];

        int x = find(subsets, next_edge.src);
        int y = find(subsets, next_edge.dest);

        // If including this edge doesn't form a cycle, add the edge to the result
        if (x != y) {
            result.push_back(next_edge);
            Union(subsets, x, y);
            e++;
        }
    }

    delete[] subsets;
    return result;
}

int main() {
    string inputFilename = "kruskalwithoutpq_am_0000006_input.txt";
    string outputFilename = "kruskalwithoutpq_am_0000006_output.txt";

    // Open the input and output files
    ifstream inputFile(inputFilename);
    ofstream outputFile(outputFilename);

    // Check if files were successfully opened
    if (!inputFile || !outputFile) {
        cerr << "Failed to open file!" << endl;
        return 1;
    }

    int n;
    inputFile >> n;

    Graph graph;
    graph.V = n;
    graph.E = 0;

    vector<char> labels(n);
    for (int i = 0; i < n; i++) {
        int index;
        char label;
        inputFile >> index >> label;
        labels[index] = label;
    }

    // Read the adjacency matrix and construct the graph
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            char weight;
            inputFile >> weight;
            if (weight != 'i') {
                int w = weight - '0';
                if (i < j) {
                    Edge edge;
                    edge.src = i;
                    edge.dest = j;
                    edge.weight = w;
                    graph.edges.push_back(edge);
                    graph.E++;
                }
            }
        }
    }

    // Start the timer for measuring the execution time
    auto startTime = std::chrono::high_resolution_clock::now();

    // Find the minimum spanning tree using Kruskal's algorithm
    vector<Edge> minimumSpanningTree = KruskalMST(graph);

    // Stop the timer and calculate the duration
    auto endTime = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime);

    // Write the output to the output file
    outputFile << n << endl;
    for (int i = 0; i < n; i++)
        outputFile << i << " " << labels[i] << endl;

    int totalWeight = 0;
    for (const auto& edge : minimumSpanningTree) {
        outputFile << labels[edge.src] << " " << labels[edge.dest] << " " << edge.weight << endl;
        totalWeight += edge.weight;
    }

    outputFile << totalWeight << endl;
    outputFile << duration.count() << "s" << endl;

    // Close the input and output files
    inputFile.close();
    outputFile.close();

    cout << "Minimum Spanning Tree has been calculated and written to " << outputFilename << endl;
    cout << duration.count() << "s" << endl;

    return 0;
}
